<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\OnboardingController;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use Laravel\Fortify\Features;
use App\Http\Controllers\SuperAdmin\UserController;

Route::get('/', function () {
    return Inertia::render('welcome', [
        'canRegister' => Features::enabled(Features::registration()),
    ]);
})->name('home');

Route::get('/onboarding', fn () =>
    Inertia::render('Onboarding/Welcome')
)->middleware(['auth'])->name('onboarding.show');
Route::post('/onboarding/skip', [OnboardingController::class, 'skip'])
    ->middleware('auth')
    ->name('onboarding.skip');


Route::middleware(['auth', 'verified'])->group(function () {

    Route::get('/super-admin/dashboard', [DashboardController::class, 'superAdmin'])
        ->middleware('role:superadmin')
        ->name('dashboard.superadmin');

    Route::get('/supervisor/dashboard', [DashboardController::class, 'supervisor'])
        ->middleware('role:supervisor')
        ->name('dashboard.supervisor');

    Route::get('/hr/dashboard', [DashboardController::class, 'hr'])
        ->middleware('role:hr')
        ->name('dashboard.hr');

    Route::get('/sitemanager/dashboard', [DashboardController::class, 'siteManager'])
        ->middleware('role:sitemanager')
        ->name('dashboard.sitemanager');

    Route::get('/accountant/dashboard', [DashboardController::class, 'accountant'])
        ->middleware('role:accountant')
        ->name('dashboard.accountant');

    Route::get('/fieldstaff/dashboard', [DashboardController::class, 'fieldStaff'])
        ->middleware('role:fieldstaff')
        ->name('dashboard.fieldstaff');
        
});


require __DIR__.'/settings.php';
