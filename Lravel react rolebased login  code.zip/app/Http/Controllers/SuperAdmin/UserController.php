<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Http\Requests\SuperAdmin\StoreUserRequest;
use App\Http\Requests\SuperAdmin\UpdateUserRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class UserController extends Controller
{
    public function index(Request $request): Response
    {
        $search = $request->string('search')->toString();
        $role   = $request->string('role')->toString();

        $query = User::query();

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        if ($role !== '') {
            $query->where('role', $role);
        }

        $users = $query
            ->latest()
            ->paginate(10)
            ->withQueryString();

        // KPI stats
        $stats = [
            'total'        => User::count(),
            'superadmins'  => User::where('role', 'superadmin')->count(),
            'supervisors'  => User::where('role', 'supervisor')->count(),
            'employees'    => User::where('role', 'employee')->count(),
        ];

        $roleOptions = User::query()
            ->select('role')
            ->distinct()
            ->pluck('role')
            ->values()
            ->all();

        return Inertia::render('SuperAdmin/Users/Index', [
            'users'       => UserResource::collection($users),
            'filters'     => [
                'search' => $search,
                'role'   => $role,
            ],
            'stats'       => $stats,
            'roleOptions' => $roleOptions,
        ]);
    }

    public function create(): Response
    {
        $roleOptions = ['superadmin', 'supervisor', 'employee'];

        return Inertia::render('SuperAdmin/Users/Create', [
            'roleOptions' => $roleOptions,
        ]);
    }

    public function store(StoreUserRequest $request)
    {
        User::create($request->validated());

        return redirect()
            ->route('super-admin.users.index')
            ->with('message', 'User created successfully.');
    }

    public function edit(User $user): Response
    {
        $roleOptions = ['superadmin', 'supervisor', 'employee'];

        return Inertia::render('SuperAdmin/Users/Edit', [
            'user'        => new UserResource($user),
            'roleOptions' => $roleOptions,
        ]);
    }

    public function update(UpdateUserRequest $request, User $user)
    {
        $data = $request->validated();

        if (empty($data['password'])) {
            unset($data['password']);
        }

        $user->update($data);

        return redirect()
            ->route('super-admin.users.index')
            ->with('message', 'User updated successfully.');
    }

    public function destroy(User $user)
    {
        $user->delete();

        return redirect()
            ->route('super-admin.users.index')
            ->with('message', 'User deleted successfully.');
    }
}
