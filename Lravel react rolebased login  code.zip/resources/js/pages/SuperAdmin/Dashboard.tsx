import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Head } from '@inertiajs/react';
import { Activity, Users, Settings, TrendingUp, User } from 'lucide-react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import KpiCard from '@/components/KpiCard';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Super Admin Dashboard',
        href: '/super-admin/dashboard',
    },
];

const data = [
    { name: 'Jan', users: 400, active: 240 },
    { name: 'Feb', users: 300, active: 139 },
    { name: 'Mar', users: 200, active: 980 },
    { name: 'Apr', users: 278, active: 390 },
    { name: 'May', users: 189, active: 480 },
    { name: 'Jun', users: 239, active: 380 },
    { name: 'Jul', users: 349, active: 430 },
];

const userGraph = [
    { name: "Mon", value: 200 },
    { name: "Tue", value: 340 },
    { name: "Wed", value: 420 },
    { name: "Thu", value: 380 },
    { name: "Fri", value: 460 },
    { name: "Sat", value: 500 },
    { name: "Sun", value: 620 },
];



export default function SuperAdminDashboard() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Super Admin Dashboard" />
            <div className="flex h-full flex-1 flex-col gap-6 p-4 md:p-6 bg-neutral-50 dark:bg-neutral-950">
                <div className="grid gap-6 md:grid-cols-4">
                    <KpiCard
                        title="Total Users"
                        value="1,234"
                        change="+12.5%"
                        icon={Users}
                        color="from-purple-500 to-indigo-600"
                    />
                    <KpiCard
                        title="Active Sessions"
                        value="845"
                        change="+5.2%"
                        icon={Activity}
                        color="from-cyan-500 to-blue-600"
                    />
                    <KpiCard
                        title="System Health"
                        value="98%"
                        change="+1.2%"
                        icon={Settings}
                        color="from-pink-500 to-rose-600"
                    />
                    <KpiCard
                        title="Total Present"
                        value="98%"
                        change="+1.2%"
                        icon={User}
                        color="from-orange-500 to-orange-600"
                    />
                </div>

                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    <div className="col-span-2 rounded-xl border border-neutral-200 bg-white p-6 shadow-sm dark:border-neutral-800 dark:bg-neutral-900">
                        <div className="mb-6">
                            <h3 className="text-lg font-semibold text-neutral-900 dark:text-white">User Growth Analytics</h3>
                            <p className="text-sm text-neutral-500 dark:text-neutral-400">User registration and activity trends</p>
                        </div>
                        <div className="h-[300px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={data}>
                                    <defs>
                                        <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                                            <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                                        </linearGradient>
                                        <linearGradient id="colorActive" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                                            <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" className="stroke-neutral-200 dark:stroke-neutral-800" />
                                    <XAxis dataKey="name" className="text-xs text-neutral-500" />
                                    <YAxis className="text-xs text-neutral-500" />
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: 'rgba(23, 23, 23, 0.9)',
                                            border: 'none',
                                            borderRadius: '8px',
                                            color: '#fff',
                                        }}
                                    />
                                    <Area
                                        type="monotone"
                                        dataKey="users"
                                        stroke="#8b5cf6"
                                        fillOpacity={1}
                                        fill="url(#colorUsers)"
                                    />
                                    <Area
                                        type="monotone"
                                        dataKey="active"
                                        stroke="#06b6d4"
                                        fillOpacity={1}
                                        fill="url(#colorActive)"
                                    />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    <div className="rounded-xl border border-neutral-200 bg-white p-6 shadow-sm dark:border-neutral-800 dark:bg-neutral-900">
                        <h3 className="mb-4 text-lg font-semibold text-neutral-900 dark:text-white">Recent Activity</h3>
                        <div className="space-y-4">
                            {[1, 2, 3, 4, 5].map((i) => (
                                <div key={i} className="flex items-center gap-4">
                                    <div className="h-2 w-2 rounded-full bg-green-500" />
                                    <div className="flex-1">
                                        <p className="text-sm font-medium text-neutral-900 dark:text-white">New user registered</p>
                                        <p className="text-xs text-neutral-500 dark:text-neutral-400">2 minutes ago</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </AppLayout>
    );
}
