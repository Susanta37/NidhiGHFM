import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardController::superAdmin
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/super-admin/dashboard'
 */
export const superAdmin = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: superAdmin.url(options),
    method: 'get',
})

superAdmin.definition = {
    methods: ["get","head"],
    url: '/super-admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::superAdmin
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/super-admin/dashboard'
 */
superAdmin.url = (options?: RouteQueryOptions) => {
    return superAdmin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::superAdmin
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/super-admin/dashboard'
 */
superAdmin.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: superAdmin.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::superAdmin
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/super-admin/dashboard'
 */
superAdmin.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: superAdmin.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::superAdmin
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/super-admin/dashboard'
 */
    const superAdminForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: superAdmin.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::superAdmin
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/super-admin/dashboard'
 */
        superAdminForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: superAdmin.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::superAdmin
 * @see app/Http/Controllers/DashboardController.php:9
 * @route '/super-admin/dashboard'
 */
        superAdminForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: superAdmin.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    superAdmin.form = superAdminForm
/**
* @see \App\Http\Controllers\DashboardController::supervisor
 * @see app/Http/Controllers/DashboardController.php:14
 * @route '/supervisor/dashboard'
 */
export const supervisor = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: supervisor.url(options),
    method: 'get',
})

supervisor.definition = {
    methods: ["get","head"],
    url: '/supervisor/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::supervisor
 * @see app/Http/Controllers/DashboardController.php:14
 * @route '/supervisor/dashboard'
 */
supervisor.url = (options?: RouteQueryOptions) => {
    return supervisor.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::supervisor
 * @see app/Http/Controllers/DashboardController.php:14
 * @route '/supervisor/dashboard'
 */
supervisor.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: supervisor.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::supervisor
 * @see app/Http/Controllers/DashboardController.php:14
 * @route '/supervisor/dashboard'
 */
supervisor.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: supervisor.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::supervisor
 * @see app/Http/Controllers/DashboardController.php:14
 * @route '/supervisor/dashboard'
 */
    const supervisorForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: supervisor.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::supervisor
 * @see app/Http/Controllers/DashboardController.php:14
 * @route '/supervisor/dashboard'
 */
        supervisorForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: supervisor.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::supervisor
 * @see app/Http/Controllers/DashboardController.php:14
 * @route '/supervisor/dashboard'
 */
        supervisorForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: supervisor.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    supervisor.form = supervisorForm
/**
* @see \App\Http\Controllers\DashboardController::hr
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/hr/dashboard'
 */
export const hr = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: hr.url(options),
    method: 'get',
})

hr.definition = {
    methods: ["get","head"],
    url: '/hr/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::hr
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/hr/dashboard'
 */
hr.url = (options?: RouteQueryOptions) => {
    return hr.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::hr
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/hr/dashboard'
 */
hr.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: hr.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::hr
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/hr/dashboard'
 */
hr.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: hr.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::hr
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/hr/dashboard'
 */
    const hrForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: hr.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::hr
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/hr/dashboard'
 */
        hrForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: hr.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::hr
 * @see app/Http/Controllers/DashboardController.php:19
 * @route '/hr/dashboard'
 */
        hrForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: hr.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    hr.form = hrForm
/**
* @see \App\Http\Controllers\DashboardController::siteManager
 * @see app/Http/Controllers/DashboardController.php:24
 * @route '/sitemanager/dashboard'
 */
export const siteManager = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: siteManager.url(options),
    method: 'get',
})

siteManager.definition = {
    methods: ["get","head"],
    url: '/sitemanager/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::siteManager
 * @see app/Http/Controllers/DashboardController.php:24
 * @route '/sitemanager/dashboard'
 */
siteManager.url = (options?: RouteQueryOptions) => {
    return siteManager.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::siteManager
 * @see app/Http/Controllers/DashboardController.php:24
 * @route '/sitemanager/dashboard'
 */
siteManager.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: siteManager.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::siteManager
 * @see app/Http/Controllers/DashboardController.php:24
 * @route '/sitemanager/dashboard'
 */
siteManager.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: siteManager.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::siteManager
 * @see app/Http/Controllers/DashboardController.php:24
 * @route '/sitemanager/dashboard'
 */
    const siteManagerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: siteManager.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::siteManager
 * @see app/Http/Controllers/DashboardController.php:24
 * @route '/sitemanager/dashboard'
 */
        siteManagerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: siteManager.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::siteManager
 * @see app/Http/Controllers/DashboardController.php:24
 * @route '/sitemanager/dashboard'
 */
        siteManagerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: siteManager.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    siteManager.form = siteManagerForm
/**
* @see \App\Http\Controllers\DashboardController::accountant
 * @see app/Http/Controllers/DashboardController.php:29
 * @route '/accountant/dashboard'
 */
export const accountant = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accountant.url(options),
    method: 'get',
})

accountant.definition = {
    methods: ["get","head"],
    url: '/accountant/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::accountant
 * @see app/Http/Controllers/DashboardController.php:29
 * @route '/accountant/dashboard'
 */
accountant.url = (options?: RouteQueryOptions) => {
    return accountant.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::accountant
 * @see app/Http/Controllers/DashboardController.php:29
 * @route '/accountant/dashboard'
 */
accountant.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accountant.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::accountant
 * @see app/Http/Controllers/DashboardController.php:29
 * @route '/accountant/dashboard'
 */
accountant.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: accountant.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::accountant
 * @see app/Http/Controllers/DashboardController.php:29
 * @route '/accountant/dashboard'
 */
    const accountantForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: accountant.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::accountant
 * @see app/Http/Controllers/DashboardController.php:29
 * @route '/accountant/dashboard'
 */
        accountantForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: accountant.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::accountant
 * @see app/Http/Controllers/DashboardController.php:29
 * @route '/accountant/dashboard'
 */
        accountantForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: accountant.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    accountant.form = accountantForm
/**
* @see \App\Http\Controllers\DashboardController::fieldStaff
 * @see app/Http/Controllers/DashboardController.php:34
 * @route '/fieldstaff/dashboard'
 */
export const fieldStaff = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fieldStaff.url(options),
    method: 'get',
})

fieldStaff.definition = {
    methods: ["get","head"],
    url: '/fieldstaff/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::fieldStaff
 * @see app/Http/Controllers/DashboardController.php:34
 * @route '/fieldstaff/dashboard'
 */
fieldStaff.url = (options?: RouteQueryOptions) => {
    return fieldStaff.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::fieldStaff
 * @see app/Http/Controllers/DashboardController.php:34
 * @route '/fieldstaff/dashboard'
 */
fieldStaff.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fieldStaff.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::fieldStaff
 * @see app/Http/Controllers/DashboardController.php:34
 * @route '/fieldstaff/dashboard'
 */
fieldStaff.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: fieldStaff.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::fieldStaff
 * @see app/Http/Controllers/DashboardController.php:34
 * @route '/fieldstaff/dashboard'
 */
    const fieldStaffForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: fieldStaff.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::fieldStaff
 * @see app/Http/Controllers/DashboardController.php:34
 * @route '/fieldstaff/dashboard'
 */
        fieldStaffForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: fieldStaff.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::fieldStaff
 * @see app/Http/Controllers/DashboardController.php:34
 * @route '/fieldstaff/dashboard'
 */
        fieldStaffForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: fieldStaff.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    fieldStaff.form = fieldStaffForm
const DashboardController = { superAdmin, supervisor, hr, siteManager, accountant, fieldStaff }

export default DashboardController