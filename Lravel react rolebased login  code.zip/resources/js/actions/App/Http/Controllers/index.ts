import OnboardingController from './OnboardingController'
import DashboardController from './DashboardController'
import Settings from './Settings'
const Controllers = {
    OnboardingController: Object.assign(OnboardingController, OnboardingController),
DashboardController: Object.assign(DashboardController, DashboardController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers