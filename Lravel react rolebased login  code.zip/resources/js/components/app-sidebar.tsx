import { NavFooter } from '@/components/nav-footer';
import { NavMain } from '@/components/nav-main';
import { NavUser } from '@/components/nav-user';
import {
    Sidebar,
    SidebarContent,
    SidebarFooter,
    SidebarHeader,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem,
} from '@/components/ui/sidebar';
import { type NavItem, type SharedData } from '@/types';
import { Link, usePage } from '@inertiajs/react';
import { BookOpen, Folder, LayoutGrid } from 'lucide-react';
import AppLogo from './app-logo';

const mainNavItems: NavItem[] = [
    {
        title: 'Dashboard',
        href: '/',
        icon: LayoutGrid,
    },
];

const footerNavItems: NavItem[] = [
    
];

export function AppSidebar() {
    const { auth } = usePage<SharedData>().props;

    const navItems = (() => {
        const role = auth.user.role;

        switch (role) {
            case 'superadmin':
                return [
                    {
                        title: 'Super Admin Dashboard',
                        href: '/super-admin/dashboard',
                        icon: LayoutGrid,
                    },
                    {
                        title: 'User Management',
                        href: '/super-admin/users',
                        icon: Folder,
                    },
                    {
                        title: 'System Settings',
                        href: '#',
                        icon: BookOpen,
                    },
                ];
            case 'supervisor':
                return [
                    {
                        title: 'Supervisor Dashboard',
                        href: '/supervisor/dashboard',
                        icon: LayoutGrid,
                    },
                    {
                        title: 'Team Overview',
                        href: '#',
                        icon: Folder,
                    },
                    {
                        title: 'Reports',
                        href: '#',
                        icon: BookOpen,
                    },
                ];
            case 'hr':
                return [
                    {
                        title: 'HR Dashboard',
                        href: '/hr/dashboard',
                        icon: LayoutGrid,
                    },
                    {
                        title: 'Employees',
                        href: '#',
                        icon: Folder,
                    },
                ];
            case 'sitemanager':
                return [
                    {
                        title: 'Site Manager Dashboard',
                        href: '/sitemanager/dashboard',
                        icon: LayoutGrid,
                    },
                    {
                        title: 'Sites',
                        href: '#',
                        icon: Folder,
                    },
                ];
            case 'accountant':
                return [
                    {
                        title: 'Accountant Dashboard',
                        href: '/accountant/dashboard',
                        icon: LayoutGrid,
                    },
                    {
                        title: 'Finance',
                        href: '#',
                        icon: Folder,
                    },
                ];
            case 'fieldstaff':
                return [
                    {
                        title: 'Field Staff Dashboard',
                        href: '/fieldstaff/dashboard',
                        icon: LayoutGrid,
                    },
                    {
                        title: 'Tasks',
                        href: '#',
                        icon: Folder,
                    },
                ];
            default:
                return mainNavItems;
        }
    })();

    return (
        <Sidebar collapsible="icon" variant="inset">
            <SidebarHeader>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton size="lg" asChild>
                            <Link href="/" prefetch>
                                <AppLogo />
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>
            </SidebarHeader>

            <SidebarContent>
                <NavMain items={navItems} />
            </SidebarContent>

            <SidebarFooter>
                <NavFooter items={footerNavItems} className="mt-auto" />
                <NavUser />
            </SidebarFooter>
        </Sidebar>
    );
}
